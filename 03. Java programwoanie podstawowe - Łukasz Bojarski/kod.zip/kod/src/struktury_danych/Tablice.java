package struktury_danych;

public class Tablice {

    public void wypiszOdKoncaNaParzystychIndeksach(int[] tab) {
        int i;
        for (i = tab.length - 1; i >= 0; i--) {
            if (i % 2 == 0) {
                System.out.print(tab[i] + " ");
            }
        }
        System.out.println();
    }

    public void sumaLiczbPodzielnychPrzezTrzy(int[] tab) {
        int suma = 0;
        for(int i = 0; i < tab.length; i++) {
            if(tab[i] % 3 == 0) {
                suma += tab[i]; // suma = suma + tab[i];
            }
        }
        System.out.println("Suma: " + suma);
    }

    public void sumaPieciuPierwszychMinusOstatni(int[] tab) {
        int wynik = 0;
        for(int i = 0; i <= 4; i++) {
            wynik += tab[i]; // wynik = wynik + tab[i];
        }
        wynik -= tab[tab.length - 1]; // wynik = wynik - tab[tab.length - 1];
        System.out.println("Wynik: " + wynik);
    }


    public static void main(String[] args) {
        int[] tablicaIntow = {2, 5, 10, 15, 7, -1, 4, 3};


        Tablice tablice = new Tablice();
        tablice.wypiszOdKoncaNaParzystychIndeksach(tablicaIntow);

        tablice.sumaLiczbPodzielnychPrzezTrzy(tablicaIntow);

        tablice.sumaPieciuPierwszychMinusOstatni(tablicaIntow);
    }

}
