package struktury_danych;

public class StosPelenExeception extends Exception {

    public StosPelenExeception() {
        super("Stos jest pełen! Nie dodasz więcej elementów");
    }

}
