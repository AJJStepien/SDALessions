package struktury_danych.stos_lista;

import struktury_danych.StosPelenExeception;

public class StosLista {
    private StosElem top;

    public StosLista() {
        top = null;
    }

    public void push(int value) {
        top = new StosElem(value, top);

//        inaczej:
//        StosElem elem = new StosElem(value, top);
//        top = elem;
    }

    public int peek() {
        if(isEmpty()) {
            throw new StosPustyException();
        }

        return top.getValue();
    }

    public int pop() {
        if(isEmpty()) {
            throw new StosPustyException();
        }

        int value = top.getValue();
        top = top.getPrev();
        return value;
    }

    public boolean isEmpty() {
        return top == null;

//         jeszcze inaczej:
//        return top == null ? true : false;

//        inaczej:
//        if(top == null) {
//            return true;
//        } else {
//            return false;
//        }

    }

    public void print() {
        StosElem tmp = top;
        while(tmp != null) {
            System.out.print(tmp.getValue() + " ");
            tmp = tmp.getPrev();
        }
        System.out.println();
    }

    public static void main(String[] args) {
        StosLista stosLista = new StosLista();

        stosLista.push(100);
        stosLista.push(500);
        stosLista.push(4);

        stosLista.print();

        System.out.println(stosLista.pop());

        System.out.println(stosLista.peek());
        System.out.println(stosLista.pop());
    }













}
