package struktury_danych;

import java.util.Scanner;

public class StosTablica {
    private int tab[];
    private int top;

    public StosTablica(int size) {
        tab = new int[size];
        top = -1;
    }

    public void push(int value) throws StosPelenExeception {
        if (isFull()) {
            throw new StosPelenExeception();
        }

        tab[++top] = value;

//        inaczej:
//        top++; // top = top + 1;
//        tab[top] = value;
    }

    public int peek() {
        if (isEmpty()) {
            // odpowiedni exception
        }

        return tab[top];
    }

    public int pop() {
        if (isEmpty()) {
            // odpowiedni expcetion
        }

        return tab[top--];

//        inaczej:
//        int value = tab[top];
//        top--;
//        return value;
    }

    public boolean isEmpty() {
        return top == -1;

//        inaczej:
//        if(top == -1) {
//            return true;
//        } else {
//            return false;
//        }
    }

    public boolean isFull() {
        return top == tab.length - 1;

//        inaczej:
//        if(top == tab.length - 1) {
//            return true;
//        } else {
//            return false;
//        }
    }

    public static void main(String[] args) {
        StosTablica stosTablica = new StosTablica(5);
        Scanner scanner = new Scanner(System.in);

        System.out.println(stosTablica);
        System.out.println(scanner);

        while (true) {
            System.out.println("Podaj nr: 1 - push, 2 - pop, 3 - peek, 4 - isEmpty, 0 - wyjście");
            int instrukcja = scanner.nextInt();

            switch (instrukcja) {
                case 0:
                    return;
                case 1:
                    try {
                        System.out.println("Podaj liczbe:");
                        int liczba = scanner.nextInt();
                        stosTablica.push(liczba);
                    } catch (StosPelenExeception exception) {
                        System.out.println(exception.getMessage());
                    }
                    break;
                case 2:
                    System.out.println("Pop: " + stosTablica.pop());
                    break;
                case 3:
                    System.out.println("Peek: " + stosTablica.peek());
                    break;
                case 4:
                    System.out.println("isEmpty: " + stosTablica.isEmpty());
                    break;
                default:
                    System.out.println("Nieprawidłowa instrukcja");
            }
        }



    }



}
