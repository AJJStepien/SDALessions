package algorytmy;

public class NWD {
    public int obliczOdejmujac(int a, int b) {
        while(b != 0) {
            if(a > b) {
                a = a - b;
            } else {
                b = b - a;
            }
        }
        return a;
    }

    public static void main(String[] args) {
        NWD nwd = new NWD();
        int wynik = nwd.obliczOdejmujac(12, 3);
        System.out.println("wynik NWD odejmujac = " + wynik);
    }

}
