package algorytmy;

import java.util.ArrayList;
import java.util.LinkedList;

public class Silnia {
    public static int rekurencyjnie(int liczba) {
          if(liczba == 0) {
              return 1;
          } else if(liczba == 1) {
              return 1;
          }
        System.out.println("Liczba: " + liczba);
          return liczba * rekurencyjnie(liczba - 1);
    }

    public static void main(String[] args) {
        int wynik = Silnia.rekurencyjnie(5);
        long start = System.nanoTime();

        // inne operacje

        long stop = System.nanoTime();

        long czas = stop - start;
        System.out.println("czas; " + czas);
    }


}
