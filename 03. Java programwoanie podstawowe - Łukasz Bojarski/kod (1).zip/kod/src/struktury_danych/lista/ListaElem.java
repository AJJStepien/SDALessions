package struktury_danych.lista;

public class ListaElem {
    private int value;
    private ListaElem prev;
    private ListaElem next;

    public ListaElem(int value) {
        this.value = value;
        prev = next = null;
    }

    public ListaElem getPrev() {
        return prev;
    }

    public void setPrev(ListaElem prev) {
        this.prev = prev;
    }

    public ListaElem getNext() {
        return next;
    }

    public void setNext(ListaElem next) {
        this.next = next;
    }

    public int getValue() {
        return value;
    }
}
