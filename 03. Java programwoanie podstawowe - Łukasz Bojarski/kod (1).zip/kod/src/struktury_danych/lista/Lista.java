package struktury_danych.lista;

public class Lista {
    private ListaElem first;
    private ListaElem last;

    public Lista() {
        first = last = null;
    }

    public void addFirst(int value) {
        ListaElem elem = new ListaElem(value);

        if(isEmpty()) {
            first = last = elem;
        } else {
            elem.setNext(first);
            first.setPrev(elem);
            first = elem;
        }
    }

    public boolean isEmpty() {
        return first == null && last == null; // AND
    }

    public void addLast(int value) {
        ListaElem elem = new ListaElem(value);

        if(isEmpty()) {
            first = last = elem;
        } else {
            elem.setPrev(last);
            last.setNext(elem);
            last = elem;
        }
    }

    public int peekFirst() {
        if(isEmpty()) {
            // zrób cokolwiek np. wyjątek
            return Integer.MAX_VALUE;
        }
        return first.getValue();
    }

    public int peekLast() {
        if(isEmpty()) {
            // np. wyjątek
            return Integer.MAX_VALUE;
        }
        return last.getValue();
    }

    public int pollFirst() {
        if(isEmpty()) {
            // np. wyjątek
            return Integer.MAX_VALUE;
        }

        int value = first.getValue();

        if(last == first) { // jest dokładnie jeden element w naszej liście
            first = last = null;
        } else { // jest wiele elementów w naszej liście
            first = first.getNext();
            first.setPrev(null);
        }

        return value;
    }

    public int pollLast() {
        if(isEmpty()) {
            // np. wyjątek
            return Integer.MAX_VALUE;
        }

        int value = last.getValue();

        if(last == first) { // jest dokładnie jeden element w naszej liście
            first = last = null;
        } else {
            last = last.getPrev();
            last.setNext(null);
        }

        return value;
    }

    public void show() {
        ListaElem tmp = first;
        while (tmp != null) {
            System.out.print(tmp.getValue() + " ");
            tmp = tmp.getNext();
        }
        System.out.println();
    }

    public void showReverse() {
        ListaElem tmp = last;
        while (tmp != null) {
            System.out.print(tmp.getValue() + " ");
            tmp = tmp.getPrev();
        }
        System.out.println();
    }

    public ListaElem search(int value) {
        ListaElem tmp = first;
        while (tmp != null) {
            if(tmp.getValue() == value) { // jeżeli równa szukanej liczby to zwróc cały obiekt
                return tmp;
            }
            tmp = tmp.getNext();
        }
        return null;
    }

    public boolean remove(int value) {
        ListaElem found = search(value);

        if(found == null) { // nie znaleziono, dlatego nie usunięto
            return false;
        }

        if(value == first.getValue()) {
            pollFirst();
        } else if(value == last.getValue()) {
            pollLast();
        } else {
            found.getPrev().setNext(found.getNext());
            found.getNext().setPrev(found.getPrev());
        }
        return true;
    }

    public static void main(String[] args) {
        Lista lista = new Lista();

        lista.addFirst(5);
        lista.addFirst(1);
        lista.addLast(4);

        lista.addLast(-99);

        lista.show();
        lista.showReverse();

        lista.pollFirst();
        lista.pollLast();

        lista.show();
    }





}













