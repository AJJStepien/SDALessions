package struktury_danych.kolejka_lista;

public class KolejkaLista {
    private KolejkaElem first;
    private KolejkaElem last;

    public KolejkaLista() {
        first = last = null;
    }

    public void add(int value) {
        KolejkaElem elem = new KolejkaElem(value, null);

        if(isEmpty()) { // kolejka jest pusta
            first = last = elem; // dla jednego obiektu pierwszy i ostatni są takie same
        } else { // jeżeli jest więcej obiektów w kolejce
            last.setNext(elem);
            last = elem;
        }
    }

    public int peek() {
        if(isEmpty()) {
            // albo wyjątek
            System.out.println("Nie wolno peekować, bo pusta! Powinien być exception");
            return Integer.MAX_VALUE; // robimy cokolwiek, aby program nam się nie wywalił
        }

        return first.getValue();
    }

    public boolean isEmpty() {
        return first == null;

//        inaczej:
//        if(first == null) {
//            return true;
//        } else {
//            return false;
//        }
    }

    public int poll() {
        if(isEmpty()) {
            // powinien być wyjątek
            System.out.println("Nie usunę, bo pusta kolejka!");
            return Integer.MAX_VALUE;
        }

        int value = first.getValue();
        if(first == last) { // jeżeli jest jeden element w kolejce
            first = last = null;

//            inaczej:
//            first = null;
//            last = null;
        } else {
            first = first.getNext();
        }

        return value;
    }

    public void print() {
        KolejkaElem tmp = first;
        while(tmp != null) {
            System.out.print(tmp.getValue() + " ");
            tmp = tmp.getNext();
        }
        System.out.println();
    }

    public static void main(String[] args) {
        KolejkaLista kolejkaLista = new KolejkaLista();

        kolejkaLista.add(100);
        kolejkaLista.add(500);
        kolejkaLista.add(4);

        kolejkaLista.print();

        System.out.println(kolejkaLista.peek());

        System.out.println(kolejkaLista.poll());
        System.out.println(kolejkaLista.peek());

        kolejkaLista.print();
    }








}
