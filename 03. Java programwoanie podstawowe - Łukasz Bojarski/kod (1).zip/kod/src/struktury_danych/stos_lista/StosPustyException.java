package struktury_danych.stos_lista;

public class StosPustyException extends RuntimeException {

    public StosPustyException() {
        super("Stos pusty!");
    }
}
