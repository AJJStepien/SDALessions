package pl.sda.mapy;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;

import java.io.File;
import java.io.IOException;
import java.util.List;
import java.util.Map;

public class JSONUtils {

    public void writeList(String filename, Map<School, List<Student>> mapa) {
        ObjectMapper mapper = new ObjectMapper();
        try {
            mapper.writeValue(new File(filename), mapa);
        } catch (IOException e) {
            e.printStackTrace();
        }
    }
//
    public void readList(String filename) {
        ObjectMapper mapper = new ObjectMapper();
        try {
            File file = new File(filename);
            Student[] value = mapper.readValue(file, Student[].class);
            for (int x = 0; x < value.length; x++) {
                System.out.println("Student: " + x + ":");
                System.out.println("Imię: " + value[x].getName());
                System.out.println("Nazwisko: " + value[x].getLastname());
                System.out.println("Indeks: " + value[x].getIndex());
                System.out.println("----------------------------------");
            }
        } catch (JsonProcessingException e) {
            e.printStackTrace();
        } catch (IOException e) {
            e.printStackTrace();
        }
//

}

