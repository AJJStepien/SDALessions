package pl.sda.wyjatki;

public class Product {
}
