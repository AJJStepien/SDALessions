package pl.sda.wyjatki;

public enum Cathegory {
    A,
    B,
    C
}
